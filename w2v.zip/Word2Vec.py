import os
import sys 
import json
import nltk
from gensim.models import Word2Vec
from nltk.tokenize.toktok import ToktokTokenizer
import nltk.data


entries = os.scandir('./jsons') #escaneo la carpeta con los jsons

vocabulario = []

nube = ""
tokenizer = nltk.data.load('tokenizers/punkt/spanish.pickle') #necesario para que separe las unidades semanticas en español
for entry in entries:

    print(entry.name)
    datos = open('./jsons/'+entry.name)

    palabras = json.load(datos)
    print(len(palabras['keywords']))
    for i in range(len(palabras['keywords'])):
        if float(palabras['keywords'][i]['relevance']) > 0.4: ## evaluo la relevancia de la palabra para agregarla a la nube
            nube += palabras['keywords'][i]['text']+" "
    

all_sentences = tokenizer.tokenize(nube) # tokenize todo el texto nube, se debe hacer este paso primero sino separa por letras... Aqui saco "oraciones"
all_words = [nltk.word_tokenize(sent) for sent in all_sentences] # con esto separo todas las palabras de las supuestas oraciones
word2vec = Word2Vec(all_words, min_count=1, workers=3) # este es el modelo del word2vec

vocabulario = word2vec.wv.vocab

# busco palabras similares, solo se puede con palabras que esten en el vocabulario
# es decir aun no hay contexto :(                                                        
sim_words = word2vec.wv.most_similar('afrocolombianas') 

print(sim_words)  # imprimo las palabras similares, en nuestra prueba solo le atino a una, 
# la palabra "negra" 